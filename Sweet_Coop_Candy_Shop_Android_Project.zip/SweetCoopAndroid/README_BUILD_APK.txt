SWEET CO-OP CANDY SHOP — NATIVE ANDROID APP PROJECT

This is an Android Studio project that packages the playable game inside an Android app using a local WebView. Once built and installed, it launches as a normal app from the phone's app icon and does not open a website.

BUILD AN APK
1. Install Android Studio on a computer: https://developer.android.com/studio
2. Extract this ZIP.
3. In Android Studio, choose Open and select the extracted SweetCoopAndroid folder.
4. Let Gradle sync. If Android Studio asks to install Android SDK 35 / build tools, accept.
5. For a quick installable APK, choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When it finishes, choose Locate. The APK is usually at:
   app/build/outputs/apk/debug/app-debug.apk
7. Transfer that APK to your Android phone and open it to install. Android may ask you to allow installing apps from that file manager. Only install APKs you built or trust.
8. For a release APK or Google Play release, configure a signing key and follow Android's current publishing requirements.

WHAT WORKS
- The game runs locally inside the app.
- Browser storage is enabled so the game's local save can persist on the device.
- The app does not require a hosted website to launch.

LIMITATIONS
- Real-time online multiplayer is NOT implemented; the room code is only a UI/demo.
- This ZIP is the Android Studio project/source, not a precompiled APK. It requires Android Studio to build the APK.
